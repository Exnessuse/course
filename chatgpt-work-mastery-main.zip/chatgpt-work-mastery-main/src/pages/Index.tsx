import { ChatGPTPresentation } from "@/components/ChatGPTPresentation";

const Index = () => {
  return <ChatGPTPresentation />;
};

export default Index;
