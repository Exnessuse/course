import { NotFound } from "@/components/NotFound";

export default NotFound;
